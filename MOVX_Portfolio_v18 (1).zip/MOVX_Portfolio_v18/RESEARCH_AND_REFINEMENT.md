# MOVX v7 — Research & refinement notes

## Referências verificáveis pesquisadas

- Behance — Creative Director Web | UX Strategy & Visual Design: minimalismo editorial, clareza, autoridade e movimento contido
- Behance — We Are Portfólio - Motion Design: movimento como extensão da identidade, tipografia precisa e transições funcionais
- Behance — Motionfolio Vol I: movimento como estratégia e narrativa, não como adorno
- Dribbble — Double Room Gallery redesign: curadoria em vez de quantidade, scroll cinematográfico e foco por hover
- Dribbble — Architect Case Study / Editorial Archive Website (tubik): ritmo editorial, imagem grande + detalhe arquivístico, tipografia e whitespace
- Dribbble — Designer Portfolio Case Study Page: narrativa por etapas com desafio, decisões e resultado visual
- Dribbble — Single Page Portfolio Website: sticky navigation, reveal, hover states e dark mode

## Regras adaptadas para MOVX

1. O trabalho é protagonista; UI recua
2. Motion comunica hierarquia e intenção, não decoração
3. Cada case ganha uma narrativa editorial própria
4. Grande imagem + pequenos metadados = sensação de arquivo premium
5. Hover reduz ruído ao redor e aumenta foco no item ativo
6. Home mostra curadoria, Social Media guarda profundidade
7. Case viewer tem capítulos: contexto, desafio, direção, sistema, narrativa e galeria
8. Evitar glassmorphism, badges genéricos e motion gratuito
