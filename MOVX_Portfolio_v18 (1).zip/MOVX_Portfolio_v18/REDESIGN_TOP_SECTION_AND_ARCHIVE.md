# MOVX v4 — Top Section + Social Archive Redesign

## Direction
The home returns to the editorial strength of the earlier hero: oversized typography, restrained copy, asymmetrical selected-work collage and a compact discipline index.

## Changes
- Restored the stronger headline concept: “I make visual work that moves.”
- Refined the right-side collage with three real project covers and minimal metadata.
- Replaced the oversized discipline rows with a compact 3-column chapter index.
- Removed the gray “project index / hover preview” block from Social Media.
- Added a categorized visual archive with filters:
  - All
  - Carousels
  - Campaigns
  - Product & 3D
  - Brand Systems
- The archive uses an asymmetric editorial grid instead of repetitive cards.
- Filters also filter the detailed case list below.
- Light/dark theme and page transitions remain intact.

## Research synthesis
Patterns reinforced from recent Behance/Dribbble portfolio references:
- oversized editorial typography with strong negative space
- project-first browsing rather than service-card-heavy layouts
- asymmetrical visual grids and large case imagery
- minimal project metadata
- clear categorization/filtering without dashboard-like UI
- restrained motion: reveal, hover, parallax, smooth page transitions
- avoiding generic bento/SaaS-card aesthetics when the goal is an art-direction portfolio

## Files
index.html
social-media.html
video-editor.html
ai-creator.html
styles.css
script.js
projects.js
assets/
