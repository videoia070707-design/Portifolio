# MOVX v10 — Y2K / VFX portfolio research and adaptation

## Research direction
The redesign uses early-2000s web/graphics vocabulary without turning the portfolio into a costume or a generic glassmorphism mockup.

### Behance patterns studied
- early-2000s web cases: dense visual effects, Photoshop-era compositing, stronger decorative framing and more authored splash-page composition
- Y2K website revamps: chrome text, clipped imagery, pop-up/overlay logic, nostalgic digital materials
- BLACKWIRE visual system: noise, glitch, bold hierarchy, exaggerated motion and early digital/gaming references used as a coherent identity system rather than random decoration

### Dribbble patterns studied
- retro-futuristic studio work: neutral editorial base with selected metallic/futuristic accents rather than an all-over neon treatment
- retro-futuristic loop animation: constant, seamless motion as a visual device
- modern animated portfolio work: high-contrast typography, motion supporting hierarchy, structured sections and interactive focus states

### Pinterest reference clusters studied
- Y2K web boards: chrome / holographic accents, wireframe and orbital forms, late-90s/2000s digital graphics
- portfolio web boards: editorial layouts and project-led composition
- retro-futurism boards: wireframe shapes, scanlines, optical flares and digital texture

## Michelangelo Full-Skills rules applied
- system ≠ template: the hero is an authored composition, not a reusable SaaS card layout
- one dominant hero: the social title remains the main focal point
- real work first: actual MOVX project covers are part of the hero instead of generic decorative 3D objects
- anti-AI gate: remove the generic glass rectangle, avoid random HUD/microdata and avoid decorative cards with no semantic role
- functional density: every VFX layer must support depth, motion, project identity or era reference
- variation by mechanism: clipped media strips, chrome orbit, scanlines, pixel flare, wire grid and raster texture each serve different roles
- typography remains deliberate and editorial; effects do not replace hierarchy

## Adaptation for MOVX
1. Replaced the large glass block with a project-led Y2K/VFX stage using real covers.
2. Added a chrome orbital stroke, scanlines, perspective grid and restrained optical flare.
3. Kept the existing MOVX grotesk-heavy typography and spacing system.
4. Rebuilt the moving project wall as a CSS-only conveyor so it does not depend on JS execution to move.
5. Hover pauses the conveyor and isolates the selected project.
