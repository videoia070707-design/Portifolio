(() => {
  const root = document.documentElement;
  const body = document.body;
  const projects = Array.isArray(window.MOVX_PROJECTS) ? window.MOVX_PROJECTS : [];
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches || new URLSearchParams(location.search).has('static');
  const finePointer = window.matchMedia('(pointer:fine)').matches;

  const CURATED_ORDER = [
    'voltara-operacoes',
    'hardwork-thermo-plus',
    'marina-gengival',
    'voltara-viabilidade',
    'hardwork-modo',
    'belive-cashflow',
    'voltara-vantagem',
    'marina-familia',
    'voltara-confianca-escala',
    'voltara-engenharia-aplicada',
    'voltara-infraestrutura',
    'hardwork-neon-direction',
    'motionhub'
  ];

  const bySlug = slug => projects.find(project => project.slug === slug);
  const socialBase = projects.filter(project => project.category === 'social');
  const socialProjects = [
    ...CURATED_ORDER.map(bySlug).filter(Boolean),
    ...socialBase.filter(project => !CURATED_ORDER.includes(project.slug))
  ];

  const I18N = window.MOVX_I18N || {default:'pt',ui:{},projects:{},cases:{}};
  const supportedLangs = ['en','es','pt'];
  const storageGet = key => { try { return window.localStorage?.getItem(key) || null; } catch { return null; } };
  const storageSet = (key,value) => { try { window.localStorage?.setItem(key,value); } catch {} };
  const savedLang = storageGet('movx-lang');
  let currentLang = supportedLangs.includes(savedLang) ? savedLang : (I18N.default || 'pt');

  /* Social niche taxonomy — intentionally separate from format filters */
  const industryMap = {
    'marina-gengival':'healthcare',
    'marina-familia':'healthcare',
    'voltara-operacoes':'energy',
    'voltara-vantagem':'energy',
    'voltara-viabilidade':'energy',
    'voltara-confianca-escala':'energy',
    'voltara-engenharia-aplicada':'energy',
    'voltara-infraestrutura':'energy',
    'belive-cashflow':'finance',
    'hardwork-thermo-plus':'supplements',
    'hardwork-modo':'supplements',
    'hardwork-neon-direction':'supplements',
    'motionhub':'saas'
  };
  const industryDefs = [
    { key:'all', cover:null, label:{pt:'Todos os nichos',en:'All niches',es:'Todos los nichos'}, desc:{pt:'Visão completa do arquivo',en:'Complete archive view',es:'Vista completa del archivo'} },
    { key:'energy', cover:'voltara-operacoes', label:{pt:'Energia',en:'Energy',es:'Energía'}, desc:{pt:'B2B, operação e infraestrutura',en:'B2B, operations and infrastructure',es:'B2B, operaciones e infraestructura'} },
    { key:'healthcare', cover:'marina-gengival', label:{pt:'Saúde',en:'Healthcare',es:'Salud'}, desc:{pt:'Estética, cuidado e confiança',en:'Aesthetics, care and trust',es:'Estética, cuidado y confianza'} },
    { key:'supplements', cover:'hardwork-thermo-plus', label:{pt:'Suplementos',en:'Supplements',es:'Suplementos'}, desc:{pt:'Produto, impacto e performance',en:'Product, impact and performance',es:'Producto, impacto y rendimiento'} },
    { key:'finance', cover:'belive-cashflow', label:{pt:'Finanças',en:'Finance',es:'Finanzas'}, desc:{pt:'Negócio, dados e posicionamento',en:'Business, data and positioning',es:'Negocio, datos y posicionamiento'} },
    { key:'saas', cover:'motionhub', label:{pt:'Produto digital',en:'Digital product',es:'Producto digital'}, desc:{pt:'Software criativo e storytelling de produto',en:'Creative software and product storytelling',es:'Software creativo y storytelling de producto'} }
  ];
  const getIndustry = project => project?.industry || industryMap[project?.slug] || 'all';
  socialProjects.forEach(project => { project.industry = getIndustry(project); });
  const localizeIndustry = key => industryDefs.find(item=>item.key===key)?.label?.[currentLang] || key;
  const localizeIndustryDesc = key => industryDefs.find(item=>item.key===key)?.desc?.[currentLang] || '';

  function t(key){
    return I18N.ui?.[currentLang]?.[key] ?? I18N.ui?.pt?.[key] ?? key;
  }

  function projectCopy(project){
    return {...project, ...(I18N.projects?.[project.slug]?.[currentLang] || I18N.projects?.[project.slug]?.pt || {})};
  }

  function getCaseStudy(project){
    const localized = I18N.cases?.[project.slug]?.[currentLang] || I18N.cases?.[project.slug]?.pt;
    if(localized) return localized;
    const meta = projectCopy(project);
    return {
      context: meta.description,
      challenge: currentLang === 'en' ? 'Clarify the message without losing visual identity.' : currentLang === 'es' ? 'Aclarar el mensaje sin perder identidad visual.' : 'Clarificar a mensagem sem perder identidade visual.',
      direction: meta.subtitle,
      storyArc: currentLang === 'en' ? 'Opening → development → synthesis → close.' : currentLang === 'es' ? 'Apertura → desarrollo → síntesis → cierre.' : 'Abertura → desenvolvimento → síntese → fecho.',
      paletteColors: [project.accent || '#101113','#101113','#f2efe8'],
      paletteWhy: currentLang === 'en' ? 'Accent colour creates recognition while neutral tones preserve contrast and flexibility.' : currentLang === 'es' ? 'El color de acento crea reconocimiento y los neutros preservan contraste y flexibilidad.' : 'A cor de destaque cria reconhecimento e os neutros preservam contraste e flexibilidade.',
      typography: currentLang === 'en' ? 'Fast-reading typography with a clear hierarchy between headlines and support copy.' : currentLang === 'es' ? 'Tipografía de lectura rápida con una jerarquía clara entre titulares y texto de apoyo.' : 'Tipografia de leitura rápida, com hierarquia clara entre títulos e texto de apoio.',
      composition: currentLang === 'en' ? 'Composition is driven by hierarchy, negative space and rhythm variation.' : currentLang === 'es' ? 'La composición se guía por jerarquía, espacio negativo y variación de ritmo.' : 'A composição é guiada por hierarquia, espaço negativo e variação de ritmo.',
      elements: project.tags || [],
      copyNotes: currentLang === 'en' ? 'Short copy focused on one main idea per frame.' : currentLang === 'es' ? 'Copy breve centrada en una idea principal por cuadro.' : 'Copy curta, centrada numa ideia principal por quadro.',
      rationale: currentLang === 'en' ? 'The system balances clarity, impact and consistency.' : currentLang === 'es' ? 'El sistema equilibra claridad, impacto y consistencia.' : 'O sistema equilibra clareza, impacto e consistência.'
    };
  }

  function formatLabel(format){ return t(`format.${format || 'project'}`); }

  const TAG_LABELS = {
    pt:{'Social Design':'Design Social','Carousel':'Carrossel','Healthcare':'Saúde','Family Care':'Família','B2B':'B2B','Energy':'Energia','Brand System':'Sistema de Marca','Industrial':'Industrial','Corporate':'Corporativo','3D':'3D','Finance':'Finanças','Product':'Produto','Character':'Personagem','Campaign':'Campanha','Art Direction':'Direção de Arte','SaaS':'SaaS'},
    en:{'Social Design':'Social Design','Carousel':'Carousel','Healthcare':'Healthcare','Family Care':'Family Care','B2B':'B2B','Energy':'Energy','Brand System':'Brand System','Industrial':'Industrial','Corporate':'Corporate','3D':'3D','Finance':'Finance','Product':'Product','Character':'Character','Campaign':'Campaign','Art Direction':'Art Direction','SaaS':'SaaS'},
    es:{'Social Design':'Diseño Social','Carousel':'Carrusel','Healthcare':'Salud','Family Care':'Familia','B2B':'B2B','Energy':'Energía','Brand System':'Sistema de Marca','Industrial':'Industrial','Corporate':'Corporativo','3D':'3D','Finance':'Finanzas','Product':'Producto','Character':'Personaje','Campaign':'Campaña','Art Direction':'Dirección de Arte','SaaS':'SaaS'}
  };
  function tagLabel(tag){ return TAG_LABELS[currentLang]?.[tag] || tag; }

  function applyStaticTranslations({revealTranslated=false}={}){
    root.lang = currentLang === 'pt' ? 'pt-PT' : currentLang;
    document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
    document.querySelectorAll('[data-i18n-html]').forEach(el => { const next=t(el.dataset.i18nHtml); if(el.innerHTML !== next) el.innerHTML = next; });
    document.querySelectorAll('[data-lang]').forEach(btn => {
      const active = btn.dataset.lang === currentLang;
      btn.classList.toggle('active',active);
      btn.setAttribute('aria-pressed', String(active));
    });
    if(revealTranslated){
      document.querySelectorAll('[data-i18n-html] .mask-reveal').forEach(el => el.classList.add('in'));
    }
  }

  /* Theme */
  const themeButton = document.querySelector('[data-theme-toggle]');
  const themeLabel = document.querySelector('.theme-label');
  function syncThemeLabel(){ if(themeLabel) themeLabel.textContent = root.dataset.theme === 'dark' ? t('theme.light') : t('theme.dark'); }
  function applyTheme(next){ root.dataset.theme = next; storageSet('movx-theme', next); syncThemeLabel(); }
  syncThemeLabel();
  themeButton?.addEventListener('click', () => {
    const next = root.dataset.theme === 'dark' ? 'light' : 'dark';
    if(document.startViewTransition && !reduceMotion) document.startViewTransition(() => applyTheme(next));
    else applyTheme(next);
  });

  applyStaticTranslations();
  syncThemeLabel();

  /* Page intro/outro */
  requestAnimationFrame(() => body.classList.add('page-ready'));
  document.querySelectorAll('a[data-transition]').forEach(link => {
    link.addEventListener('click', event => {
      const href = link.getAttribute('href');
      if(!href || href.startsWith('#') || href.startsWith('http') || link.target === '_blank' || reduceMotion) return;
      event.preventDefault();
      body.classList.remove('page-ready');
      body.classList.add('page-leaving');
      setTimeout(() => location.href = href, 560);
    });
  });

  /* Header + progress + velocity */
  const header = document.querySelector('.site-header');
  const progress = document.querySelector('.scroll-progress span');
  let lastY = window.scrollY;
  let tickerX = 0;
  let tickerVelocity = 0;
  function onScroll(){
    const y = window.scrollY;
    header?.classList.toggle('scrolled', y > 10);
    const total = Math.max(1, document.documentElement.scrollHeight - innerHeight);
    if(progress) progress.style.transform = `scaleX(${Math.min(1,y/total)})`;
    tickerVelocity += (y-lastY) * .065;
    lastY = y;
  }
  addEventListener('scroll', onScroll, {passive:true});
  onScroll();

  const ticker = document.querySelector('.velocity-track');
  if(ticker && !reduceMotion){
    function tickTicker(){
      tickerVelocity *= .9;
      tickerX -= .34 + tickerVelocity;
      const half = ticker.scrollWidth / 2;
      if(Math.abs(tickerX) > half) tickerX = 0;
      ticker.style.setProperty('--ticker-x', `${tickerX}px`);
      requestAnimationFrame(tickTicker);
    }
    requestAnimationFrame(tickTicker);
  }

  /* Reveal utilities */
  function registerRevealEls(scope=document){
    const els = scope.querySelectorAll('.reveal,.mask-reveal,.media-reveal');
    if('IntersectionObserver' in window && !reduceMotion){
      const observer = new IntersectionObserver(entries => entries.forEach(entry => {
        if(entry.isIntersecting){ entry.target.classList.add('in'); observer.unobserve(entry.target); }
      }), {threshold:.08, rootMargin:'0px 0px -4% 0px'});
      els.forEach(el => observer.observe(el));
    } else els.forEach(el => el.classList.add('in'));
  }
  registerRevealEls();

  /* Scroll parallax */
  const parallax = [...document.querySelectorAll('.parallax-media')];
  if(parallax.length && !reduceMotion){
    let raf = false;
    const update = () => {
      parallax.forEach(el => {
        const rect = el.getBoundingClientRect();
        const center = rect.top + rect.height/2 - innerHeight/2;
        const amount = Math.max(-24, Math.min(24, -center * .035));
        el.style.setProperty('--parallax-y', `${amount}px`);
      });
      raf = false;
    };
    addEventListener('scroll', () => { if(!raf){ raf=true; requestAnimationFrame(update); } }, {passive:true});
    update();
  }

  /* Hero pointer drift */
  const collage = document.querySelector('.hero-collage');
  if(collage && finePointer && !reduceMotion){
    const cards = [...collage.querySelectorAll('.hero-card')];
    collage.addEventListener('pointermove', event => {
      const rect = collage.getBoundingClientRect();
      const nx = (event.clientX-rect.left)/rect.width-.5;
      const ny = (event.clientY-rect.top)/rect.height-.5;
      cards.forEach((card,index) => {
        const d = (index+1)*5;
        const base = index===0?'rotate(-1.8deg)':index===1?'rotate(1.1deg)':'rotate(-.7deg)';
        card.style.transform = `${base} translate3d(${nx*d}px,${ny*d}px,0)`;
      });
    });
    collage.addEventListener('pointerleave', () => cards.forEach(card => card.style.removeProperty('transform')));
  }

  /* Magnetic and micro tilt */
  if(finePointer && !reduceMotion){
    document.querySelectorAll('[data-magnetic]').forEach(el => {
      el.addEventListener('pointermove', event => {
        const rect=el.getBoundingClientRect();
        const x=(event.clientX-rect.left-rect.width/2)*.12;
        const y=(event.clientY-rect.top-rect.height/2)*.12;
        el.style.transform=`translate(${x}px,${y}px)`;
      });
      el.addEventListener('pointerleave',()=>el.style.transform='');
    });
  }

  function attachTilt(scope=document){
    if(!finePointer || reduceMotion) return;
    scope.querySelectorAll('.archive-card,.loop-card').forEach(card => {
      if(card.dataset.tiltReady) return;
      card.dataset.tiltReady = '1';
      card.addEventListener('pointermove', event => {
        const rect = card.getBoundingClientRect();
        const x = (event.clientX - rect.left) / rect.width - .5;
        const y = (event.clientY - rect.top) / rect.height - .5;
        card.style.setProperty('--rx', `${(-y * 2.2).toFixed(2)}deg`);
        card.style.setProperty('--ry', `${(x * 2.6).toFixed(2)}deg`);
      });
      card.addEventListener('pointerleave', () => {
        card.style.setProperty('--rx','0deg');
        card.style.setProperty('--ry','0deg');
      });
    });
  }

  function attachProjectSpotlight(scope=document){
    if(!finePointer || reduceMotion) return;
    scope.querySelectorAll('.project-cover').forEach(card => {
      if(card.dataset.spotReady) return;
      card.dataset.spotReady='1';
      card.addEventListener('pointermove', event => {
        const rect = card.getBoundingClientRect();
        const x = ((event.clientX - rect.left) / rect.width) * 100;
        const y = ((event.clientY - rect.top) / rect.height) * 100;
        card.style.setProperty('--mx', `${x}%`);
        card.style.setProperty('--my', `${y}%`);
      });
    });
  }

  /* Mobile menu */
  const menuButton = document.querySelector('.menu-button');
  const mobileMenu = document.querySelector('.mobile-menu');
  menuButton?.addEventListener('click',()=>{
    const open = mobileMenu?.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(Boolean(open)));
  });

  /* Premium case viewer */
  const viewer = document.getElementById('caseViewer');
  const caseHero = document.getElementById('caseHero');
  const caseInfo = document.getElementById('caseInfo');
  const caseSlides = document.getElementById('caseSlides');
  const closeCase = document.getElementById('caseClose');
  const casePrev = document.getElementById('casePrev');
  const caseNext = document.getElementById('caseNext');
  const caseTopLabel = document.getElementById('caseTopLabel');
  const caseProgress = document.getElementById('caseProgress');
  let currentCaseSlug = null;
  let lastOpenPoint = {x:'50%', y:'50%'};

  function adjacentProject(slug, delta){
    const index = socialProjects.findIndex(project => project.slug === slug);
    if(index < 0) return socialProjects[0];
    return socialProjects[(index + delta + socialProjects.length) % socialProjects.length];
  }

  function buildCaseInfo(project){
    const study = getCaseStudy(project);
    const meta = projectCopy(project);
    return `
      <div class="case-kicker">${t('case.studyKicker')} / ${project.client}</div>
      <h2>${meta.title}</h2>
      <p class="case-lead">${meta.subtitle}</p>
      <p class="case-description">${meta.description}</p>
      <div class="project-tags">${project.tags.map(tag=>`<span>${tagLabel(tag)}</span>`).join('')}</div>
      <div class="case-facts">
        <div><span>${t('case.client')}</span><strong>${project.client}</strong></div>
        <div><span>${t('case.format')}</span><strong>${formatLabel(project.format)}</strong></div>
        <div><span>${t('case.industry')}</span><strong>${localizeIndustry(getIndustry(project))}</strong></div>
        <div><span>${t('case.piecesLabel')}</span><strong>${project.slides.length}</strong></div>
      </div>

      <div class="case-chapter-label">${t('case.chapter1')}</div>
      <section class="case-study-block"><strong>${t('case.context')}</strong><p>${study.context}</p></section>
      <section class="case-study-block"><strong>${t('case.challenge')}</strong><p>${study.challenge}</p></section>

      <div class="case-chapter-label">${t('case.chapter2')}</div>
      <section class="case-study-block"><strong>${t('case.direction')}</strong><p>${study.direction}</p></section>
      <section class="case-study-block"><strong>${t('case.storyArc')}</strong><p>${study.storyArc}</p></section>

      <div class="case-chapter-label">${t('case.chapter3')}</div>
      <section class="case-study-block"><strong>${t('case.palette')}</strong><div class="case-swatches case-swatches--labeled">${study.paletteColors.map((color,index) => `<span class="case-swatch"><i style="background:${color}"></i><em>${study.paletteLabels?.[index] || color}</em></span>`).join('')}</div><p>${study.paletteWhy}</p></section>
      <section class="case-study-block"><strong>${t('case.typography')}</strong><p>${study.typography}</p></section>
      <section class="case-study-block"><strong>${t('case.composition')}</strong><p>${study.composition}</p></section>
      ${study.imageTreatment ? `<section class="case-study-block"><strong>${t('case.imageTreatment')}</strong><p>${study.imageTreatment}</p></section>` : ''}
      <section class="case-study-block"><strong>${t('case.elements')}</strong><ul>${study.elements.map(item => `<li>${item}</li>`).join('')}</ul></section>
      ${study.systemRule ? `<section class="case-study-block case-study-block--rule"><strong>${t('case.systemRule')}</strong><p>${study.systemRule}</p></section>` : ''}

      <div class="case-chapter-label">${t('case.chapter4')}</div>
      <section class="case-study-block"><strong>${t('case.copy')}</strong><p>${study.copyNotes}</p></section>
      <div class="case-study-note"><strong class="case-kicker">${t('case.rationale')}</strong><p>${study.rationale}</p></div>`;
  }

  function renderCase(project){
    if(!viewer || !caseHero || !caseInfo || !caseSlides) return;
    const currentIndex = socialProjects.findIndex(item => item.slug === project.slug);
    const next = adjacentProject(project.slug, 1);
    const meta = projectCopy(project);
    const nextMeta = projectCopy(next);
    caseTopLabel && (caseTopLabel.textContent = `${String(currentIndex+1).padStart(2,'0')} / ${String(socialProjects.length).padStart(2,'0')} — ${project.client}`);
    casePrev && (casePrev.textContent = t('case.prev'));
    caseNext && (caseNext.textContent = t('case.next'));
    closeCase && (closeCase.textContent = t('case.close'));
    caseHero.innerHTML = `
      <div class="case-hero__media"><img src="${project.cover}" alt="${project.client} — ${meta.title}"></div>
      <div class="case-hero__veil"></div>
      <div class="container case-hero__content">
        <div class="case-hero__eyebrow">${t('nav.social').toUpperCase()} / ${String(currentIndex+1).padStart(2,'0')} / ${String(socialProjects.length).padStart(2,'0')}</div>
        <h1 class="case-hero__title">${meta.title}</h1>
        <div class="case-hero__deck"><p>${meta.subtitle}</p><span>${project.slides.length} ${t('case.pieces')} / ${formatLabel(project.format)}</span></div>
      </div>`;
    caseInfo.innerHTML = buildCaseInfo(project);
    caseSlides.innerHTML = project.slides.map((src,index)=>`
      <figure class="reveal in">
        <div class="case-index"><span>${String(index+1).padStart(2,'0')} / ${String(project.slides.length).padStart(2,'0')}</span><span>${project.client}</span></div>
        <div class="case-slide-frame"><img src="${src}" alt="${project.client} — ${meta.title}, slide ${index+1}" loading="eager"></div>
      </figure>`).join('') + `
      <div class="case-end">
        <strong>${t('case.nextCase')}<br>${nextMeta.title}</strong>
        <button type="button" data-open-project="${next.slug}">${t('case.openNext')}</button>
      </div>`;
  }

  function openProject(slug, point){
    const project = bySlug(slug);
    if(!project || !viewer) return;
    const wasOpen = viewer.classList.contains('open');
    currentCaseSlug = project.slug;
    if(point){
      lastOpenPoint = {x:`${point.x}px`, y:`${point.y}px`};
      viewer.style.setProperty('--open-x', lastOpenPoint.x);
      viewer.style.setProperty('--open-y', lastOpenPoint.y);
    }
    renderCase(project);
    viewer.classList.remove('closing');
    viewer.classList.add('open');
    viewer.setAttribute('aria-hidden','false');
    body.classList.add('case-open');
    viewer.scrollTop = 0;
    if(wasOpen && !reduceMotion){
      viewer.animate([{opacity:.82},{opacity:1}],{duration:320,easing:'cubic-bezier(.16,1,.3,1)'});
    }
    requestAnimationFrame(updateCaseProgress);
  }

  function finishClose(){
    if(!viewer) return;
    viewer.classList.remove('open','closing');
    viewer.setAttribute('aria-hidden','true');
    body.classList.remove('case-open');
    currentCaseSlug = null;
  }

  function closeProject(){
    if(!viewer || !viewer.classList.contains('open')) return;
    if(reduceMotion){ finishClose(); return; }
    viewer.classList.add('closing');
    setTimeout(finishClose, 470);
  }

  function updateCaseProgress(){
    if(!viewer || !caseProgress) return;
    const total = Math.max(1, viewer.scrollHeight - viewer.clientHeight);
    caseProgress.style.transform = `scaleX(${Math.min(1,viewer.scrollTop/total)})`;
  }
  viewer?.addEventListener('scroll', updateCaseProgress, {passive:true});

  document.addEventListener('click', event => {
    const open = event.target.closest('[data-open-project]');
    if(open){
      event.preventDefault();
      openProject(open.dataset.openProject, {x:event.clientX || innerWidth/2, y:event.clientY || innerHeight/2});
    }
  });
  closeCase?.addEventListener('click', closeProject);
  casePrev?.addEventListener('click', () => currentCaseSlug && openProject(adjacentProject(currentCaseSlug,-1).slug));
  caseNext?.addEventListener('click', () => currentCaseSlug && openProject(adjacentProject(currentCaseSlug,1).slug));
  document.addEventListener('keydown', event => {
    if(event.key === 'Escape') closeProject();
    if(viewer?.classList.contains('open') && event.key === 'ArrowRight' && currentCaseSlug) openProject(adjacentProject(currentCaseSlug,1).slug);
    if(viewer?.classList.contains('open') && event.key === 'ArrowLeft' && currentCaseSlug) openProject(adjacentProject(currentCaseSlug,-1).slug);
  });

  /* Home selected editorial index */
  const selectedMount = document.getElementById('selectedProjects');
  const selectedSlugs = ['voltara-operacoes','hardwork-thermo-plus','marina-gengival','belive-cashflow','hardwork-modo'];
  function renderSelectedProjects(){
    if(!selectedMount) return;
    const selected = selectedSlugs.map(bySlug).filter(Boolean);
    selectedMount.innerHTML = selected.map((project,index)=>{
      const meta = projectCopy(project);
      return `
      <article class="selected-index-row reveal" data-open-project="${project.slug}">
        <span class="selected-index-row__num">${String(index+1).padStart(2,'0')}</span>
        <span class="selected-index-row__client">${project.client}</span>
        <strong class="selected-index-row__title">${meta.title}</strong>
        <span class="selected-index-row__meta">${formatLabel(project.format)}</span>
        <div class="selected-index-row__preview"><img src="${project.cover}" alt="" loading="lazy"></div>
      </article>`;
    }).join('');
    registerRevealEls(selectedMount);
  }

  /* Social archive */
  const archiveMount = document.getElementById('archiveGrid');
  const listMount = document.getElementById('projectsList');
  const filtersMount = document.getElementById('archiveFilters');
  const nicheFiltersMount = document.getElementById('archiveNicheFilters');
  const nicheGridMount = document.getElementById('nicheGrid');
  const heroCategoryRail = document.getElementById('heroCategoryRail');
  const archiveFilterStatus = document.getElementById('archiveFilterStatus');
  const loopWall = document.getElementById('loopWall');
  const archiveState = { format:'all', niche:'all' };
  let loopRaf = null;
  let loopRowsState = [];

  function stopConveyorLoop(){
    if(loopRaf){ cancelAnimationFrame(loopRaf); loopRaf = null; }
  }

  function initConveyorLoop(){
    stopConveyorLoop();
    if(!loopWall || reduceMotion) return;
    const rows = [...loopWall.querySelectorAll('.loop-row')];
    if(!rows.length) return;

    loopRowsState = rows.map((row,index) => {
      const track = row.querySelector('.loop-track');
      const distance = Math.max(1, track.scrollWidth / 2);
      const reverse = row.classList.contains('reverse');
      return {
        row,
        track,
        distance,
        reverse,
        speed: [0.36,0.44,0.4][index % 3],
        x: reverse ? -distance : 0
      };
    });

    let paused = false;
    const setPaused = value => {
      paused = value;
      loopWall.dataset.loopPaused = value ? 'true' : 'false';
    };
    loopWall.onmouseenter = () => setPaused(true);
    loopWall.onmouseleave = () => setPaused(false);

    let last = performance.now();
    const frame = now => {
      const dt = Math.min(32, now - last);
      last = now;
      if(!paused){
        loopRowsState.forEach(state => {
          const delta = state.speed * dt;
          if(state.reverse){
            state.x += delta;
            if(state.x >= 0) state.x -= state.distance;
          } else {
            state.x -= delta;
            if(Math.abs(state.x) >= state.distance) state.x += state.distance;
          }
          state.track.style.transform = `translate3d(${state.x}px,0,0)`;
        });
      }
      loopRaf = requestAnimationFrame(frame);
    };
    loopRaf = requestAnimationFrame(frame);
  }

  addEventListener('resize', () => {
    if(!loopWall || !loopWall.children.length || reduceMotion) return;
    clearTimeout(window.__movxLoopResize);
    window.__movxLoopResize = setTimeout(initConveyorLoop, 120);
  }, {passive:true});
  const filterDefs = [
    { key:'all', labelKey:'filter.all' },
    { key:'carousel', labelKey:'filter.carousel' },
    { key:'campaign', labelKey:'filter.campaign' },
    { key:'product', labelKey:'filter.product' },
    { key:'system', labelKey:'filter.system' }
  ];

  function getActiveFormat(){ return archiveState.format; }
  function getActiveNiche(){ return archiveState.niche; }
  function getFilteredProjects(format=archiveState.format, niche=archiveState.niche){
    return socialProjects.filter(project => (format === 'all' || project.format === format) && (niche === 'all' || getIndustry(project) === niche));
  }
  function buildFilters(activeFilter=archiveState.format, activeNiche=archiveState.niche){
    if(filtersMount){
      const countFor = key => key === 'all' ? socialProjects.length : socialProjects.filter(project => project.format === key).length;
      filtersMount.innerHTML = filterDefs.map(item=>`<button class="archive-filter ${item.key===activeFilter?'active':''}" type="button" data-project-filter="${item.key}">${t(item.labelKey)} <span>${countFor(item.key)}</span></button>`).join('');
    }
    if(nicheFiltersMount){
      const countForNiche = key => key === 'all' ? socialProjects.length : socialProjects.filter(project => getIndustry(project) === key).length;
      nicheFiltersMount.innerHTML = industryDefs.map(item=>`<button class="archive-filter ${item.key===activeNiche?'active':''}" type="button" data-project-niche="${item.key}">${localizeIndustry(item.key)} <span>${countForNiche(item.key)}</span></button>`).join('');
    }
  }

  function renderHeroCategoryRail(){
    if(!heroCategoryRail) return;
    const entries = industryDefs.filter(item=>item.key!=='all').map(item=>{
      const count = socialProjects.filter(project => getIndustry(project) === item.key).length;
      return `<button class="social-cover-art__cat" type="button" data-project-niche="${item.key}" data-scroll-target="#archiveControls"><strong>${localizeIndustry(item.key)}</strong><em>${String(count).padStart(2,'0')}</em></button>`;
    });
    heroCategoryRail.innerHTML = entries.join('');
  }

  function renderNicheGrid(activeNiche='all'){
    if(!nicheGridMount) return;
    const entries = industryDefs.filter(item => item.key !== 'all').map((item,index) => {
      const count = socialProjects.filter(project => getIndustry(project) === item.key).length;
      const representative = bySlug(item.cover);
      return `<article class="niche-card ${activeNiche===item.key?'active':''}" data-project-niche="${item.key}" tabindex="0">
        <div class="niche-card__media">${representative ? `<img src="${representative.cover}" alt="" loading="lazy">` : ''}</div>
        <div class="niche-card__content">
          <span class="niche-card__num">${String(index+1).padStart(2,'0')} / ${String(count).padStart(2,'0')}</span>
          <h3 class="niche-card__title">${localizeIndustry(item.key)}</h3>
          <p class="niche-card__desc">${localizeIndustryDesc(item.key)}</p>
          <div class="niche-card__meta"><span>${count} ${t('case.project')}</span><span>↘</span></div>
        </div>
      </article>`;
    });
    nicheGridMount.innerHTML = entries.join('');
  }

  function renderLoopWall(items){
    if(!loopWall) return;
    const offsets = [0,3,7];
    stopConveyorLoop();
    loopWall.innerHTML = offsets.map((offset,rowIndex)=>{
      const row = [...items.slice(offset),...items.slice(0,offset)];
      const doubled = [...row,...row];
      return `<div class="loop-row ${rowIndex%2?'reverse':''}"><div class="loop-track">${doubled.map((project,itemIndex)=>{
        const meta = projectCopy(project);
        return `
        <article class="loop-card" data-open-project="${project.slug}" aria-label="${t('case.openAria')} ${project.client} — ${meta.title}">
          <img src="${project.cover}" alt="${project.client} — ${meta.title}" loading="lazy">
          <div class="loop-card__overlay">
            <span class="loop-card__eyebrow">${project.client}</span>
            <strong class="loop-card__title">${meta.title}</strong>
            <span class="loop-card__meta">${String((itemIndex%row.length)+1).padStart(2,'0')} / ${formatLabel(project.format)}</span>
            <button class="loop-card__button" type="button" data-open-project="${project.slug}">${t('case.full')}</button>
          </div>
        </article>`;
      }).join('')}</div></div>`;
    }).join('');
    attachTilt(loopWall);
    initConveyorLoop();
  }

  function renderArchive(items){
    if(!archiveMount) return;
    const layouts = ['wide','tall','square','landscape','tall','wide','square','landscape','wide','tall','square','wide','landscape'];
    archiveMount.innerHTML = items.map((project,index)=>{
      const meta = projectCopy(project);
      return `
      <article class="archive-card ${layouts[index%layouts.length]} media-reveal" data-open-project="${project.slug}" data-industry="${getIndustry(project)}">
        <div class="archive-card__media"><img src="${project.cover}" alt="${project.client} — ${meta.title}" loading="lazy"></div>
        <div class="archive-card__caption">
          <span>${String(index+1).padStart(2,'0')}</span>
          <div><strong>${project.client}</strong><small>${meta.title}</small></div>
          <em>${formatLabel(project.format)}</em>
        </div>
      </article>`;
    }).join('');
    registerRevealEls(archiveMount);
    attachTilt(archiveMount);
  }

  function renderProjectList(items){
    if(!listMount) return;
    listMount.innerHTML = items.map((project,index)=>{
      const meta = projectCopy(project);
      return `
      <article class="project-entry" id="${project.slug}" data-format="${project.format||'project'}" data-industry="${getIndustry(project)}">
        <div class="project-copy reveal">
          <div class="project-no">${String(index+1).padStart(2,'0')} / ${String(items.length).padStart(2,'0')}</div>
          <div class="project-client">${project.client}</div>
          <h2>${meta.title}</h2>
          <p class="project-subtitle">${meta.subtitle}</p>
          <p class="project-desc">${meta.description}</p>
          <div class="project-tags">${project.tags.map(tag=>`<span>${tagLabel(tag)}</span>`).join('')}</div>
          <button class="case-button" type="button" data-open-project="${project.slug}">${t('case.full')}</button>
        </div>
        <div class="project-cover media-reveal parallax-media" data-open-project="${project.slug}"><img src="${project.cover}" alt="${project.client} — ${meta.title}" loading="lazy"></div>
      </article>`;
    }).join('');
    registerRevealEls(listMount);
    attachProjectSpotlight(listMount);
  }

  function syncArchiveControls(){
    filtersMount?.querySelectorAll('[data-project-filter]').forEach(item => item.classList.toggle('active', item.dataset.projectFilter === archiveState.format));
    nicheFiltersMount?.querySelectorAll('[data-project-niche]').forEach(item => item.classList.toggle('active', item.dataset.projectNiche === archiveState.niche));
    nicheGridMount?.querySelectorAll('[data-project-niche]').forEach(item => item.classList.toggle('active', item.dataset.projectNiche === archiveState.niche));
  }

  function applyArchiveState(){
    const filtered = getFilteredProjects();
    renderArchive(filtered);
    listMount?.querySelectorAll('.project-entry').forEach(el => {
      const formatOk = archiveState.format === 'all' || el.dataset.format === archiveState.format;
      const nicheOk = archiveState.niche === 'all' || el.dataset.industry === archiveState.niche;
      el.classList.toggle('is-filtered-out', !(formatOk && nicheOk));
    });
    renderNicheGrid(archiveState.niche);
    syncArchiveControls();
    if(archiveFilterStatus){
      const label = filtered.length === 1 ? t('filter.resultSingular') : t('filter.resultPlural');
      archiveFilterStatus.textContent = `${String(filtered.length).padStart(2,'0')} ${label}`;
    }
  }

  function refreshLocalizedUI({revealTranslated=true}={}){
    applyStaticTranslations({revealTranslated});
    syncThemeLabel();
    renderSelectedProjects();
    buildFilters(archiveState.format, archiveState.niche);
    renderNicheGrid(archiveState.niche);
    renderLoopWall(socialProjects);
    renderProjectList(socialProjects);
    applyArchiveState();
    if(currentCaseSlug){
      const openCase = bySlug(currentCaseSlug);
      if(openCase) renderCase(openCase);
    }
  }

  function setLanguage(lang){
    if(!supportedLangs.includes(lang) || lang === currentLang) return;
    currentLang = lang;
    storageSet('movx-lang', lang);
    refreshLocalizedUI({revealTranslated:true});
  }

  document.querySelectorAll('[data-lang]').forEach(button => button.addEventListener('click', () => setLanguage(button.dataset.lang)));

  function setActiveNiche(niche){
    archiveState.niche = industryDefs.some(item => item.key === niche) ? niche : 'all';
    applyArchiveState();
  }
  function setActiveFormat(format){
    archiveState.format = filterDefs.some(item => item.key === format) ? format : 'all';
    applyArchiveState();
  }

  if(archiveMount || listMount || filtersMount || loopWall || selectedMount){
    refreshLocalizedUI({revealTranslated:false});
    filtersMount?.addEventListener('click', event => {
      const button = event.target.closest('[data-project-filter]');
      if(!button) return;
      setActiveFormat(button.dataset.projectFilter);
    });
    nicheFiltersMount?.addEventListener('click', event => {
      const button = event.target.closest('[data-project-niche]');
      if(!button) return;
      setActiveNiche(button.dataset.projectNiche);
    });
    nicheGridMount?.addEventListener('click', event => {
      const card = event.target.closest('[data-project-niche]');
      if(!card) return;
      setActiveNiche(card.dataset.projectNiche);
      document.getElementById('archiveControls')?.scrollIntoView({behavior: reduceMotion ? 'auto' : 'smooth', block:'start'});
    });
    nicheGridMount?.addEventListener('keydown', event => {
      const card = event.target.closest('[data-project-niche]');
      if(card && (event.key === 'Enter' || event.key === ' ')){
        event.preventDefault();
        setActiveNiche(card.dataset.projectNiche);
        document.getElementById('archiveControls')?.scrollIntoView({behavior: reduceMotion ? 'auto' : 'smooth', block:'start'});
      }
    });
    document.addEventListener('click', event => {
      const trigger = event.target.closest('[data-scroll-target]');
      if(!trigger) return;
      const niche = trigger.dataset.projectNiche;
      if(niche) setActiveNiche(niche);
      const target = document.querySelector(trigger.dataset.scrollTarget);
      target?.scrollIntoView({behavior: reduceMotion ? 'auto' : 'smooth', block:'start'});
    });
  } else {
    applyStaticTranslations({revealTranslated:false});
    syncThemeLabel();
  }

  /* Contact brief builder */
  const contactForm = document.getElementById('contactForm');
  const contactCopy = document.getElementById('contactCopy');
  const contactMail = document.getElementById('contactMail');
  function buildContactBrief(){
    if(!contactForm) return '';
    const fd = new FormData(contactForm);
    const rows = [
      ['Name', fd.get('name') || '—'],
      ['Email', fd.get('email') || '—'],
      ['Project', fd.get('project') || '—'],
      ['Message', fd.get('message') || '—']
    ];
    return rows.map(([k,v]) => `${k}: ${v}`).join('\n');
  }
  contactCopy?.addEventListener('click', async () => {
    const text = buildContactBrief();
    try{ await navigator.clipboard.writeText(text); }catch{ const ta=document.createElement('textarea');ta.value=text;document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove(); }
    const original=contactCopy.textContent; contactCopy.textContent=t('contact.copied');
    setTimeout(()=>contactCopy.textContent=original,1800);
  });
  contactMail?.addEventListener('click', () => {
    const subject=encodeURIComponent('MOVX — New project');
    const bodyText=encodeURIComponent(buildContactBrief());
    contactMail.href=`mailto:?subject=${subject}&body=${bodyText}`;
  });


  /* Unified single-page navigation */
  const unifiedNavLinks = [...document.querySelectorAll('.nav--editorial a[href^="#"], .mobile-menu a[href^="#"]')];
  unifiedNavLinks.forEach(link => link.addEventListener('click', () => {
    mobileMenu?.classList.remove('open');
    menuButton?.setAttribute('aria-expanded','false');
  }));
  const navSections = ['livingArchive','about','services','contact'].map(id=>document.getElementById(id)).filter(Boolean);
  if(navSections.length && 'IntersectionObserver' in window){
    const spy = new IntersectionObserver(entries => {
      const visible = entries.filter(e=>e.isIntersecting).sort((a,b)=>b.intersectionRatio-a.intersectionRatio)[0];
      if(!visible) return;
      const id = visible.target.id;
      document.querySelectorAll('.nav--editorial a[href^="#"]').forEach(link => {
        const href = link.getAttribute('href');
        link.classList.toggle('is-active', href === `#${id}` || (id === 'livingArchive' && href === '#livingArchive'));
      });
    }, {rootMargin:'-22% 0px -62% 0px',threshold:[0,.25,.5,.75]});
    navSections.forEach(section=>spy.observe(section));
  }

  attachTilt();
  attachProjectSpotlight();
})();
