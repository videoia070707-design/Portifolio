# MOVX — Motion & Architecture Redesign Plan v3

## 1. Correção de arquitetura

Todos os carrosséis recebidos até agora pertencem à disciplina **Social Media**. Nenhum foi classificado como Video Editing ou AI Creator nesta versão.

A arquitetura foi separada em páginas reais:

- `index.html` — entrada da MOVX e seleção curta de trabalhos
- `social-media.html` — arquivo completo dos carrosséis atuais
- `video-editor.html` — página reservada, sem cases falsos até o envio de vídeos
- `ai-creator.html` — página reservada, sem reutilizar os carrosséis como “cases de AI”

O tema escolhido pelo visitante é persistido entre todas as páginas.

## 2. Pesquisa de motion/interação

### Padrões encontrados em portfolios e componentes high-end

**Ashcroft Design / Framer**
- pinned horizontal gallery
- parallax por imagem
- scroll progress
- masked menu/link reveals
- magnetic buttons
- velocity-reactive marquee
- cursor-follow media
- reduced-motion support

**Lumière / Framer**
- smooth scroll
- parallax
- image reveals
- animated project cards
- transições cuidadosas entre momentos da página

**Project Reveal / Framer**
- sticky project showcase
- reveal orientado pelo scroll
- media grande tomando protagonismo

**Works Gallery / Framer**
- pinning durante scroll
- profundidade/perspective
- transformação progressiva da mídia durante a rolagem

**Scroll Portfolio Pro / Framer**
- movimento ligado à velocidade do scroll
- inertia / dynamic skew
- hover que coloca um projeto em foco e reduz os outros
- light/dark themes

**Dribbble — portfolio interaction prototypes**
- fade/slide section reveals
- sticky navigation
- smooth anchor transitions
- hover feedback em portfolio cards
- dark mode como camada funcional, não como redesign separado

## 3. O que foi adaptado para MOVX

O objetivo não foi empilhar efeitos. Cada animação foi escolhida por função.

### Page curtain transition
Ao trocar entre Home, Social Media, Video Editor e AI Creator, um wipe editorial cobre a tela e revela a página seguinte. Isso diferencia capítulos sem parecer uma apresentação de template.

### Masked typography reveal
Headlines grandes entram por máscara vertical. Aplicado somente em títulos-chave, seguindo o tipo de reveal editorial encontrado nos portfolios pesquisados.

### Scroll progress
Uma linha mínima no topo mostra o progresso da página. Não adiciona ruído visual.

### Image reveal
Covers importantes usam `clip-path` e escala sutil ao entrar no viewport. É mais próximo de fotografia/editorial do que de “cards flutuantes”.

### Subtle parallax
Imagens selecionadas reagem ao scroll com deslocamento pequeno. O movimento cria profundidade sem impedir a leitura.

### Hero pointer drift
Somente em desktop com ponteiro fino, as três peças do hero respondem alguns pixels ao cursor. Não é usado no restante do site.

### Velocity marquee
A faixa tipográfica reage à direção e à velocidade da rolagem. Foi inspirada no marquee velocity-reactive de portfolios atuais, mas implementada de modo mais discreto.

### Sticky project index + live preview
Na página Social Media, a lista de projetos e a imagem de preview funcionam como um índice editorial. Hover troca o cover com transição curta. Clique abre o case completo.

### Sticky case copy
Durante a navegação de cada projeto, o texto do case permanece temporariamente fixo enquanto o cover ocupa o palco. Isso ajuda leitura e hierarquia.

### Theme inversion
Botão Light / Dark inverte a linguagem principal branco-preto / preto-branco e persiste via `localStorage`. O sistema usa as mesmas composições nos dois temas, em vez de criar dois sites diferentes.

### Magnetic micro-interaction
O controle de tema possui resposta sutil ao cursor em desktop. Nenhum botão grande recebeu “floating physics” para evitar aparência artificial.

### Case viewer
Cases abrem em uma página/overlay de leitura vertical, com as peças em sequência. A animação de entrada é curta e o foco continua nas artes.

### Reduced motion
`prefers-reduced-motion` desativa transições, parallax e efeitos que dependem de movimento.

## 4. Efeitos pesquisados que NÃO foram usados

- cursor customizado permanente
- excesso de 3D perspective
- blur forte em todas as transições
- glow/neon de interface
- floating cards
- scroll hijacking
- smooth-scroll artificial que altera demais o comportamento do navegador
- Lottie sem função narrativa

Eles são comuns em showcases, mas no MOVX poderiam competir com os próprios projetos e voltar a criar a sensação de site “feito por IA”.

## 5. Direção de design mantida

- editorial > dashboard
- projetos grandes > thumbnails pequenas
- texto como composição > labels decorativas
- assimetria controlada > bento grid repetitivo
- poucas bordas e poucos componentes
- imagens fazem o trabalho visual pesado
- cada disciplina possui página própria
- nenhum case é inventado para preencher espaço

## 6. Próximo conteúdo

### Video Editor
Quando o material chegar, estruturar em:
1. Showreel 30–45 s
2. Short Form / Reels
3. Ads / VSL
4. Motion / Kinetic Type
5. Before & After
6. Breakdown de edição e sound design

### AI Creator
Quando o material chegar, estruturar em:
1. Brief / objetivo
2. processo ou prompt strategy quando relevante
3. consistency study
4. composição / art direction
5. integração com design real
6. outputs finais
7. comparação de variações quando trouxer valor

## 7. Fontes pesquisadas

- Framer Gallery — Dev's Portfolio
- Framer Marketplace — ASHCROFT Design
- Framer Marketplace — LUMIÈRE cinematic
- Framer Marketplace — Scroll Portfolio Pro
- Framer Marketplace — Project Reveal
- Framer Marketplace — Works Gallery
- Dribbble — Single Page Portfolio Website / interaction prototype
- Codrops — Infinite GSAP Scroll Gallery with Parallax and Flip Transitions
