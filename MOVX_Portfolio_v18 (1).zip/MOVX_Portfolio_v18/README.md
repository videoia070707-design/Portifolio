# MOVX Creative Portfolio

Static multi-page portfolio with Social Media, Video Editing and AI Creator chapters.

## Local preview
Run a local server from this folder:

```bash
python -m http.server 8080
```

Open `http://localhost:8080`.

## GitHub Pages
This project includes `.github/workflows/pages.yml` and `.nojekyll`.
After pushing to the `main` branch of a GitHub repository, enable **Settings → Pages → Source: GitHub Actions**.
