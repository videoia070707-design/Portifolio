# MOVX v17 — editorial portfolio research notes

## Mechanisms adapted
- Portfolio as narrative, not a gallery: positioning → selected work → point of view → services/process → soft conversion.
- Strong editorial typography paired with clean sans/mono metadata.
- Deep black / soft neutral foundation so project imagery carries colour.
- Indexed work and table-like filters instead of rounded dashboard pills.
- Controlled motion: marquee/conveyor and hover focus without ornamental motion everywhere.
- Serif-led section titles for personality; sans/mono for navigation, data and utility.
- Negative space and deliberate cropping to keep the portfolio premium.

## Source families reviewed
- Behance: Creative Director / Brand Architect portfolio UX case studies; editorial campaign systems.
- Dribbble: dark editorial personal portfolios, filmmaker portfolio UI, editorial art-director portfolios.
- Pinterest: Y2K and editorial references used as mood-board input; colour/trend references treated as inspiration rather than site structure.

## MOVX translation
- Hero remains authored and image-led.
- Home now has About, Services, Process and Contact instead of ending after work.
- Social Media filtering is an editorial index, not a pill-heavy control panel.
- Case studies now expose palette names/roles, image treatment and the rule that keeps each visual system coherent.
- Dark mode is true black; red is an accent rather than a background colour.
